// class MyColor {
//   final appColor = Colors.fromARGB(255, 21, 101, 192);
// }
