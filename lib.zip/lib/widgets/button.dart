import 'package:flutter/material.dart';

class CustomFlatButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String text;
  final Color color;
  final Color textColor;

  const CustomFlatButton({
    super.key,
    required this.onPressed,
    required this.text,
    required this.color,
    required this.textColor,
  });

  @override
  _CustomFlatButtonState createState() => _CustomFlatButtonState();
}

class _CustomFlatButtonState extends State<CustomFlatButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() {
          _isPressed = true;
        });
      },
      onTapUp: (_) {
        setState(() {
          _isPressed = false;
        });
        widget.onPressed();
      },
      onTapCancel: () {
        setState(() {
          _isPressed = false;
        });
      },
      child: AnimatedContainer(
        height: 50,
        width: 150,
        duration: const Duration(milliseconds: 100),
        decoration: BoxDecoration(
          color: _isPressed ? widget.color.withOpacity(0.5) : widget.color,
          borderRadius: BorderRadius.circular(8.0),
        ),
        padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 24.0),
        child: Text(
          widget.text,
          style: TextStyle(
            color: widget.textColor,
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
