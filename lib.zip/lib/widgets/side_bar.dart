import 'package:flutter/material.dart';
import 'package:fun_app/widgets/Text_button.dart';

class Sidebar extends StatelessWidget {
  final bool isNewHost;
  final TextEditingController numberController;
  final TextEditingController otpController;
  final VoidCallback onSignUpPressed;
  final VoidCallback onLogInPressed;
  final VoidCallback onGetOTP;

  const Sidebar({
    Key? key,
    required this.isNewHost,
    required this.numberController,
    required this.otpController,
    required this.onSignUpPressed,
    required this.onLogInPressed,
    required this.onGetOTP,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.25,
      color: Colors.blue[500],
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: MediaQuery.of(context).size.height * 0.12),
          Image.asset(
            isNewHost
                ? 'images/host_register_qr.png'
                : 'images/host_login_qr.png',
            height: 200,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                CustomTextButton(
                  text: 'SignUp',
                  onPressed: onSignUpPressed,
                ),
                CustomTextButton(
                  text: 'LogIn',
                  onPressed: onLogInPressed,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: numberController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: 'Enter Whatsapp Number',
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16.0, vertical: 12.0),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: BorderSide.none,
                ),
                prefixIcon: const Icon(Icons.phone),
              ),
            ),
          ),
          CustomTextButton(
            text: 'Get OTP',
            onPressed: onGetOTP,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: otpController,
              decoration: InputDecoration(
                hintText: 'Enter OTP',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
