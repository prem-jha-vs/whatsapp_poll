import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fun_app/widgets/button.dart';

class HostDashboard extends StatefulWidget {
  const HostDashboard({Key? key}) : super(key: key);

  @override
  State<HostDashboard> createState() => _HostDashboardState();
}

class _HostDashboardState extends State<HostDashboard> {
  TextEditingController addEventController = TextEditingController();
  bool showEventList = false;
  bool showAddEvent = false;
  late List<dynamic> events;

  @override
  void initState() {
    super.initState();
    loadEvents();
  }

  Future<void> loadEvents() async {
    String data =
        await DefaultAssetBundle.of(context).loadString('events.json');

    setState(() {
      events = json.decode(data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(color: Colors.blue[800]),
        child: Row(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width * 0.15,
              decoration: BoxDecoration(color: Colors.blue[500]),
              child: Column(
                children: <Widget>[
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.12,
                    child: const Text(
                      'My Events',
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  CustomFlatButton(
                    onPressed: () {
                      setState(() {
                        //showAddEvent = !showAddEvent;
                      });
                    },
                    text: 'Create Event',
                    color: Colors.deepPurpleAccent,
                    textColor: Colors.white,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CustomFlatButton(
                    onPressed: () {
                      setState(() {
                        showEventList = !showEventList;
                      });
                    },
                    text: 'View Event',
                    color: Colors.deepPurpleAccent,
                    textColor: Colors.white,
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.blue[800],
                child: Column(
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * 0.12,
                      decoration: BoxDecoration(color: Colors.blue[500]),
                      child: const Row(
                        children: <Widget>[
                          SizedBox(
                            width: 50,
                          ),
                        ],
                      ),
                    ),
                    if (showEventList)
                      Expanded(
                        child: Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width,
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          decoration: BoxDecoration(color: Colors.blue[950]),
                          child: ListView.builder(
                            itemCount: events.length,
                            itemBuilder: (context, index) {
                              // Access event data from JSON
                              Map<String, dynamic> event = events[index];
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: Card(
                                  color: Colors.blue[300],
                                  elevation: 3,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      event['name'],
                                      style:
                                          const TextStyle(color: Colors.white),
                                    ),
                                    subtitle: Text(
                                      event['location'] + ' - ' + event['date'],
                                      style: const TextStyle(
                                          color: Colors.white38),
                                    ),
                                    onTap: () {},
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    if (showAddEvent)
                      Expanded(
                          child: Container(
                        width: MediaQuery.of(context).size.width * 0.32,
                        decoration: BoxDecoration(color: Colors.blue[200]),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                TextField(
                                  controller: addEventController,
                                  decoration: InputDecoration(
                                    hintText: 'Name of Event',
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide: BorderSide.none,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ))
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
